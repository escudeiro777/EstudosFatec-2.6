from hashlib import sha256
senOK = 'E0BEBD22819993425814866B62701E2919EA26F1370499C1037B53B9D49C2C8A'       
nro = 0 
while nro < 3: 
        nro = nro + 1 
        login = (input('login: ')) 
        senha = (input('senha: '))
        senha_hash = sha256(senha.encode()).hexdigest()
        if login == 'ABC' and senha_hash.upper() == senOK:
            print ('Acesso permitido') 
            break 
        else: 
              print ('Acesso negado')
        if nro == 2:
            print("Atenção! Última tentativa!")
        if nro == 3: 
              print ('Usuário bloqueado') 
quit()   
