import sqlite3
# Conexão com SGDB
conn = sqlite3.connect("dbempresa.db")
cursor = conn.cursor()

# Obtém cpf para pesquisar e prepara instrução SQL
cpf = input("CPF: ")

isql =        "  Select cpf, nome, login, senha, dtcadastro, "
isql = isql + "    case when idstatus = 1 then 'Ativo' else 'Bloqueado' end as situacao"
isql = isql + "  from usuario"
isql = isql + "  where cpf = " + cpf

# envia instrução sql para ser executada
cursor.execute(isql)

#  recebe retorno do sgdb
rs = cursor.fetchone()


# trata os dados recebidos
if rs != None:
    print ("CPF: ", rs[0])
    print ("Nome: ", rs[1])
    print ("Login: ", rs[2])
    print ("Senha: ", rs[3])
    print ("Data cadastro: ", rs[4])
    print ("Status:", rs[5])
    input("Pressione <enter> para continuar")
else:
    print("Usuário não cadastrado!")
conn.close
quit()

