import sqlite3
# Conexão com SGDB
conn = sqlite3.connect("dbloja.db")
cursor = conn.cursor()
# prepara instrução sql
cod = input("Codigo do produto: ")
isql = '''
           Select *
           from Produto
           where codprod = 
       ''' + cod
# envia instrução sql para ser executada
cursor.execute(isql)
#  recebe retorno do sgdb
linha = cursor.fetchone()
# trata os dados recebidos
print ("Código: ", linha[0])
print ("Descrição: ", linha[1])
print ("Saldo: ", linha[2])
print ("Saldo minimo: ", linha[3])
print ("Preço de venda: ", linha[4])
print ("Preço de custo ", linha[5])
input("Pressione <enter> para continuar")
conn.close()
