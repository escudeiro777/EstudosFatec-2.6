from hashlib import sha256  # Para obter o hash equivalente a senha
from datetime import datetime
print("==============================")
print("#       Cadastramento        #")
print("="*30)
vcpf = input("CPF: ")
vlogin = input("Login: ")
vsenha = input("Senha: ")
vstatus = input("Status (1-Ativo 2-Bloqueado: ")
continua = input("Confirma a inclusão deste usuário? (S/N): ")
# Obtém hash equivalente a senha informada
senha_hash = sha256(vsenha.encode()).hexdigest()
print(senha_hash)
# obtem data/hora do sistema
data_hora = datetime.now().strftime('%y-%m-%d %H:%M:%S')
print(data_hora)





