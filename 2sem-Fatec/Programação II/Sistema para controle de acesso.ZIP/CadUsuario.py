from hashlib import sha256    #Para obter o hash equivalente a senha
from datetime import datetime #Para obter a data hora do sistema
print("==============================")
print("#       Cadastramento        #")
print("="*30)
vcpf = input("CPF: ")
vnome = input("Nome: ")
vlogin = input("Login: ")
vsenha = input("Senha: ")
vstatus = input("Status (1-Ativo 2-Bloqueado: ")
continua = input("Confirma a inclusão deste usuário? (S/N): ")
# Obtém hash equivalente a senha informada
senha_hash = sha256(vsenha.encode()).hexdigest()
# obtem data/hora do sistema
data_hora = datetime.now().strftime('%y-%m-%d %H:%M:%S')
## preparar instrução SQL
isql =        " insert into usuario values ("
isql = isql + vcpf
isql = isql + ", " + "'" + vnome + "'"
isql = isql + ", " + "'" + vlogin + "'"
isql = isql + ", " + "'" + senha_hash + "'"
isql = isql + ", " + "'" + data_hora + "'"
isql = isql + ", " + vstatus
isql = isql + ");"
 
















